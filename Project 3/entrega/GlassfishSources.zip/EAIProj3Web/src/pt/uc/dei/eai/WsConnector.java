package pt.uc.dei.eai;

import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import org.netbeans.xml.schema.userschema.*;
import org.netbeans.xml.schema.cameraresponse.*;
import org.netbeans.xml.schema.userschema.UserInfo;
import pt.uc.dei.eai.common.Order;
import pt.uc.dei.eai.common.OrderStatus;

public class WsConnector {

	/* USERS */
    
    public org.netbeans.xml.schema.userschema.User InvokeLogin(String user, String password) {
        usercompositeorchestrator.CasaService1 service = new usercompositeorchestrator.CasaService1();
        usercompositeorchestrator.WSLoginWrapperPortType port = service.getLogin();
        UserInfo loginRequest = new org.netbeans.xml.schema.userschema.UserInfo();
        loginRequest.setUsername(user);
        loginRequest.setPassword(password);
        User userLogged = port.wsLoginWrapperOperation(loginRequest);
        return userLogged;
    }

    public boolean InvokeRegisterUser(String user, String password, String address, String email) {
        usercompositeorchestrator.CasaService2 service = new usercompositeorchestrator.CasaService2();
        usercompositeorchestrator.WSRegisterUserPortType port = service.getRegister();
        org.netbeans.xml.schema.userschema.UserRegister registerUserRequest = new org.netbeans.xml.schema.userschema.UserRegister();
        registerUserRequest.setUsername(user);
        registerUserRequest.setPassword(password);
        registerUserRequest.setAddress(address);
        registerUserRequest.setEmail(email);
        UserRegisterInfo result = port.wsRegisterUserOperation(registerUserRequest);
        return result.isResult();
    }

    /* ORDERS */
    
    public List<pt.uc.dei.eai.common.Camera> InvokeSearchCameras(String search) {
        ordercompositeorchestrator.CasaService2 service = new ordercompositeorchestrator.CasaService2();
        ordercompositeorchestrator.WSBPELSearchCamerasPortType port = service.getSearchCameras();
        CameraModelSearch cameraSearchRequest = new CameraModelSearch();
        cameraSearchRequest.setModelName(search);
        CameraSearchResponse result = port.wsBPELSearchCamerasOperation(cameraSearchRequest);
        List<pt.uc.dei.eai.common.Camera> cameras = null;
        if (result != null && result.getCameras() != null &&
                result.getCameras().getIdAndModelAndPrice() != null &&
                result.getCameras().getIdAndModelAndPrice().size() > 0) {
            cameras = new ArrayList<pt.uc.dei.eai.common.Camera>();
            List<Serializable> rawCameras = result.getCameras().getIdAndModelAndPrice();
            for (int i = 0; i < rawCameras.size(); i+=3) {
                pt.uc.dei.eai.common.Camera newCamera = new pt.uc.dei.eai.common.Camera();
                newCamera.setId((Integer)rawCameras.get(i));
                newCamera.setModel((String)rawCameras.get(i+1));
                newCamera.setPrice((Float)rawCameras.get(i+2));
                cameras.add(newCamera);
            }
        }
        return cameras;
    }

    public org.netbeans.xml.schema.cameraresponse.CameraInfo InvokeGetCameraInfo(Integer cameraId) {
        ordercompositeorchestrator.CasaService1 service = new ordercompositeorchestrator.CasaService1();
        ordercompositeorchestrator.WSBPELGetCameraInfoPortType port = service.getGetCamera();
        org.netbeans.xml.schema.cameraresponse.CameraSearch cameraRequest = new org.netbeans.xml.schema.cameraresponse.CameraSearch();
        cameraRequest.setModelId(cameraId.intValue());
        org.netbeans.xml.schema.cameraresponse.CameraInfo result = port.wsBPELGetCameraInfoOperation(cameraRequest);
        return result;
    }

   	/* PURCHASES */

    /**
     * Invokes the Checkout BPEL web service.
     * @param username
     * @param password
     * @param cart      Shopping cart with the cameras to buy.
     * @return          True if the checkout was successfull, false otherwise.
     */
    public boolean InvokeCheckout(String username, String password, ShoppingCart cart) {
        if (cart == null) {
            return false;
        }
        purchasecompositeorchestrator.CasaService1 service = new purchasecompositeorchestrator.CasaService1();
        purchasecompositeorchestrator.WSBPELCheckoutPortType port = service.getCheckout();
        org.netbeans.xml.schema.purchases.CheckoutRequest checkoutRequest = new org.netbeans.xml.schema.purchases.CheckoutRequest();
        org.netbeans.xml.schema.purchases.UserInfo userInfo = new org.netbeans.xml.schema.purchases.UserInfo();
        // set user info
        org.netbeans.xml.schema.userschema.User userLogged = InvokeLogin(username, password);
        userInfo.setUsername(username);
        userInfo.setPassword(password);
        userInfo.setAddress(userLogged.getAddress());
        userInfo.setEmail(userLogged.getEmail());
        checkoutRequest.setUserInfo(userInfo);
        // set lista de cameras a comprar
        org.netbeans.xml.schema.purchases.CheckoutRequest.Cameras cameras = new org.netbeans.xml.schema.purchases.CheckoutRequest.Cameras();
        for (int i = 0; i < cart.getNumberCameras(); i++) {
            org.netbeans.xml.schema.purchases.CameraInfo cameraToBuy = new org.netbeans.xml.schema.purchases.CameraInfo();
            cameraToBuy.setId(cart.getId(i));
            cameraToBuy.setModel(cart.getModel(i));
            cameraToBuy.setPrice(cart.getPrice(i));
            cameras.getCameraInfo().add(cameraToBuy);
        }
        checkoutRequest.setCameras(cameras);
        org.netbeans.xml.schema.purchases.CheckoutConfirmation result = port.wsBPELCheckoutOperation(checkoutRequest);
        return result.isSucess();
    }

    /**
     * Returns information about a specific purchase.
     * @param orderId
     * @return
     */
    public org.netbeans.xml.schema.purchases.SinglePurchase InvokeGetPurchaseInfo(int orderId) {
        purchasecompositeorchestrator.CasaService2 service = new purchasecompositeorchestrator.CasaService2();
        purchasecompositeorchestrator.WSBPELGetPurchaseInfoPortType port = service.getGetPurchaseInfo();
        org.netbeans.xml.schema.purchases.GetPurchaseInfo getPurchaseInfoRequest = new org.netbeans.xml.schema.purchases.GetPurchaseInfo();
        getPurchaseInfoRequest.setOrderId(orderId);
        org.netbeans.xml.schema.purchases.SinglePurchase result = port.wsBPELGetPurchaseInfoOperation(getPurchaseInfoRequest);
        return result;
    }

    /*
    public void InvokeShipped(int orderId, String shippedDates) {
        purchasecompositeorchestrator.CasaService3 service = new purchasecompositeorchestrator.CasaService3();
        purchasecompositeorchestrator.WSBPELShippedPortType port = service.getShipped();
        org.netbeans.xml.schema.purchases.OrderInfo shippedRequest = new org.netbeans.xml.schema.purchases.OrderInfo();
        shippedRequest.setOrderId(orderId);
        shippedRequest.setShippedDates(shippedDates);
        port.wsBPELShippedOperation(shippedRequest);
    }
    */

    public List<Order> InvokeGetPurchases(String username) {
        purchasecompositeorchestrator.CasaService4 service = new purchasecompositeorchestrator.CasaService4();
        purchasecompositeorchestrator.WSBPELGetPurchasesPortType port = service.getGetPurchases();
        org.netbeans.xml.schema.purchases.PurchaseInfo purchasesRequest = new org.netbeans.xml.schema.purchases.PurchaseInfo();
        purchasesRequest.setUsername(username);
        org.netbeans.xml.schema.purchases.PurchasesResponse result = port.wsBPELGetPurchasesOperation(purchasesRequest);
        List<JAXBElement<?>> rawOrders = result.getPurchases().getEmailAddressAndIdAndOrderStatus();
        List<Order> orders = new ArrayList<Order>();
        for (int i = 0; i < rawOrders.size(); i+=7) {
            Order newOrder = new Order();
            try {
                newOrder.setEmailAddress(jaxbMarshalToString(rawOrders.get(i)));
                newOrder.setId(Integer.parseInt(jaxbMarshalToString(rawOrders.get(i+1))));
                OrderStatus status = null;
                if (jaxbMarshalToString(rawOrders.get(i+2)).equals("0")) {
                    status = OrderStatus.NOT_PAID;
                } else if (jaxbMarshalToString(rawOrders.get(i+2)).equals("1")) {
                    status = OrderStatus.SHIPPED;
                } else if (jaxbMarshalToString(rawOrders.get(i+2)).equals("2")) {
                    status = OrderStatus.WAITING_FOR_SHIPPING;
                }
                newOrder.setOrderStatus(status);
                newOrder.setOrderedCameras(null);
                try {
                    SimpleDateFormat dtf = new SimpleDateFormat();
                    newOrder.setPurchaseDate(dtf.parse(jaxbMarshalToString(rawOrders.get(i + 4))));
                } catch (ParseException ex) {
                    Logger.getLogger(WsConnector.class.getName()).log(Level.SEVERE, null, ex);
                }
                newOrder.setShippingAddress(jaxbMarshalToString(rawOrders.get(i+5)));
                newOrder.setUsername(jaxbMarshalToString(rawOrders.get(i+6)));
            } catch (JAXBException ex) {
                Logger.getLogger(WsConnector.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(WsConnector.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return orders;
    }

    private String jaxbMarshalToString(JAXBElement jaxbObj) throws javax.xml.bind.JAXBException, java.io.IOException {
        java.io.StringWriter sw = new java.io.StringWriter();
        javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(jaxbObj.getClass().getPackage().getName());
        javax.xml.bind.Marshaller marshaller = jaxbCtx.createMarshaller();
        marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_ENCODING, "UTF-8");
        //NOI18N
        marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        marshaller.marshal(jaxbObj, sw);
        sw.close();
        return sw.toString();
    }

    
}
