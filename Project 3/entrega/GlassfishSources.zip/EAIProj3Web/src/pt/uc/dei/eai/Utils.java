package pt.uc.dei.eai;

public class Utils {

    public static boolean stringArrayContains(String stringToFind, String[] stringArray) {
        if (stringArray != null && stringArray.length > 0) {
            for (int i = 0; i < stringArray.length; i++) {
                if (stringToFind.equalsIgnoreCase(stringArray[i])) {
                    return true;
                }
            }
        }
        return false;
    }
}
