/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package project1;

/**
 * Contains a camera resolution, with the horizontal and the vertical
 * components.
 * @author csimoes
 */
public class Resolution {
	public int Horizontal;
	public int Vertical;
	public long NumberPixels;
}
