package project1;

public class CameraSummaryDetails {
	public String model;
	public String date;
	public String minResolution;
	public String minResolutionVertical;
	public String minResolutionHorizontal;
	public String maxResolution;
	public String maxResolutionVertical;
	public String maxResolutionHorizontal;
}
