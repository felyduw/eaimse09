/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package project1;

import java.util.List;

/**
 *
 * @author csimoes
 */
public class Brand {
	public String name;
	public int numberCameras;
	public List<Camera> cameras; 
}
