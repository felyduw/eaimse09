/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package camerasearchxml;

/**
 *
 * @author csimoes
 */
public class CameraModel {

	private String Url;

	/**
	 * Get the value of Url
	 *
	 * @return the value of Url
	 */
	public String getUrl() {
		return Url;
	}

	/**
	 * Set the value of Url
	 *
	 * @param Url new value of Url
	 */
	public void setUrl(String Url) {
		this.Url = Url;
	}

	private String Description;

	/**
	 * Get the value of Description
	 *
	 * @return the value of Description
	 */
	public String getDescription() {
		return Description;
	}

	/**
	 * Set the value of Description
	 *
	 * @param Description new value of Description
	 */
	public void setDescription(String Description) {
		this.Description = Description;
	}


}
